import React, { Component } from 'react';
import './UserInfo.css';
import {NavLink} from 'react-router-dom';

class UserInfo extends Component {
  render() {
    return (
	<div></div>
    );
  }
}

export default UserInfo;
