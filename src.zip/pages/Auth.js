import React, { Component } from 'react';

class Auth extends Component {
  render() {
    return (
      <div>
        안녕
      </div>
    );
  }
}

export default Auth;