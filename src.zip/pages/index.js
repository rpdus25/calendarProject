export { default as Login } from './Login';
export { default as Auth } from './Auth';
export { MainView as Home } from '../component/MainView';